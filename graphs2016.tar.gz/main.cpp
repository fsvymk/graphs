#include "graphs.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    graphs w;
    w.show();

    return a.exec();
}
